@echo off
echo Reading Airflow password...
for /f "tokens=2 delims=:}" %%a in ('docker exec airflow_webserver bash -c "cat /opt/airflow/simple_auth_manager_passwords.json.generated" 2^>nul') do (
    set PWD=%%a
    set PWD=!PWD:"=!
    set PWD=!PWD: =!
    echo !PWD! > airflow_password.txt
)
echo Starting Pipeline Control Center...
python main.py
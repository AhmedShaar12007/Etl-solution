import requests

with open("airflow_password.txt") as f:
    pwd = f.read().strip()

print("Password:", pwd)

r = requests.post(
    "http://localhost:8080/auth/token",
    json={"username": "admin", "password": pwd},
    timeout=5
)
print("Token status:", r.status_code)
token = r.json().get("access_token", "")
print("Got token:", bool(token))

r2 = requests.get(
    "http://localhost:8080/api/v2/dags",
    headers={"Authorization": f"Bearer {token}"},
    timeout=5
)
print("DAGs status:", r2.status_code)
print("DAGs count:", len(r2.json().get("dags", [])))

r3 = requests.post(
    "http://localhost:8080/api/v2/dags/client_b_pipeline/dagRuns",
    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    json={"conf": {}},
    timeout=5
)
print("Trigger status:", r3.status_code)
print("Trigger response:", r3.text[:300])
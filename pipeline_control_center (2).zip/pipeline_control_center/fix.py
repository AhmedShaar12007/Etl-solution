with open('main.py', 'r') as f:
    content = f.read()

content = content.replace(
    '"schema":        cfg.get("source_schema", "")',
    '"schema":        "",\n            "extra":         json.dumps({"service_name": cfg["source_service"]})'
)

old = '    restart = subprocess.run("docker restart airflow_webserver",\n                             shell=True, capture_output=True, text=True)\n    results["restart"] = restart.stdout.strip()\n    return {"status": "deployed"'
new = '    restart = subprocess.run("docker restart airflow_webserver",\n                             shell=True, capture_output=True, text=True)\n    results["restart"] = restart.stdout.strip()\n    import time\n    time.sleep(35)\n    return {"status": "deployed"'
content = content.replace(old, new)

with open('main.py', 'w') as f:
    f.write(content)
print('done')